from typing import Any, Dict
from datetime import datetime
from app.access.models import ToolName
from app.tools.base import BaseTool, ToolResult
from app.context.models import UserContext

class GreetingTool(BaseTool):
    """Tool that returns a friendly greeting without hitting the database."""
    
    @property
    def tool_name(self) -> ToolName:
        return ToolName.GREETING_TOOL
        
    def execute(self, context: UserContext, **kwargs) -> ToolResult:
        """Returns a static greeting response."""
        return ToolResult(
            success=True,
            data={"greeting": "Hello! I am Farm360 Copilot. I am ready to assist you with your farm, crops, land records, or any agricultural questions you have today."},
            message="Greeting generated.",
            source="System",
            tool_name=self.tool_name,
            timestamp=datetime.utcnow()
        )
